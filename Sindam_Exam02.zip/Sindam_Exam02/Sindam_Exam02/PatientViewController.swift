//
//  ViewController.swift
//  Sindam_Exam02
//
//  Created by Sindam,Suresh on 4/11/23.
//

import UIKit

class PatientViewController: UIViewController {
    
    
    @IBOutlet weak var patientNameTextField: UITextField!
    
    @IBOutlet weak var patientIdTextField: UITextField!
    
    @IBOutlet weak var statusLbl: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var physicianDetailsBtn: UIButton!
    
    @IBOutlet weak var reservationDetailsBtn: UIButton!
    
    
    var patientDetails = PatientDetails()
    
    var patientDetailsArr = patientsArray
    
    var data = ""
    var discease = ""
    var diagonisi = ""
    var disImg = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        statusLbl.isHidden = true
        imgView.isHidden = true
        physicianDetailsBtn.isHidden = true
        reservationDetailsBtn.isHidden = true
        
//        physicianDetailsBtn.isEnabled = false
//        reservationDetailsBtn.isEnabled = false
    }
    
    
    @IBAction func patientIdEditingChanged(_ sender: UITextField) {
        
        //statusLbl.text! += patientIdTextField.text!
        
        for i in 0..<patientDetailsArr.count {
            if(patientDetailsArr[i].patientId == patientIdTextField.text!) {
                statusLbl.isHidden = false
                statusLbl.text = "Patient ID \(patientIdTextField.text!) found"
                discease = patientDetailsArr[i].diseaseName
                diagonisi = patientDetailsArr[i].doctorName
                disImg = patientDetailsArr[i].diseaseImage
                imgView.isHidden = false
                imgView.image = UIImage(named: "default")
                physicianDetailsBtn.isHidden = false
                if(patientDetailsArr[i].reservation == "Yes") {
                    reservationDetailsBtn.isHidden = false
                } else {
                    reservationDetailsBtn.isHidden = true
                }
                break
            } else {
                statusLbl.isHidden = false
                statusLbl.text = "Patient ID \(patientIdTextField.text!) not found"
                physicianDetailsBtn.isHidden = true
                reservationDetailsBtn.isHidden = true
                imgView.isHidden = true
            }
        }
        
        if(patientIdTextField.text!.isEmpty) {
            statusLbl.isHidden = true
            imgView.isHidden = true
            physicianDetailsBtn.isHidden = true
            reservationDetailsBtn.isHidden = true
        }
    }
    
    
    @IBAction func fPhyDetailsBtnAction(_ sender: UIButton) {
        data = "\(patientNameTextField.text!) with Patient ID \(patientIdTextField.text!) is suffering from \(discease) and diagonsis under \(diagonisi)"
    }
    
    
    @IBAction func fResDetailsBtnAction(_ sender: UIButton) {
        data = "Room is resered for patient \(patientNameTextField.text!) with id \(patientIdTextField.text!)"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "phy") {
            let dvc = segue.destination as! DetailsViewController
            dvc.dis = data
            dvc.imgName = disImg
        } else if(segue.identifier == "res") {
            let dvc = segue.destination as! ReservationViewController
            dvc.dis = data
            dvc.imgName = disImg
        }
        
        
    }
    
    



}

