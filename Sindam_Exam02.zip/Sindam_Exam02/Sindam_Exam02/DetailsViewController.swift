//
//  DetailsViewController.swift
//  Sindam_Exam02
//
//  Created by Sindam,Suresh on 4/11/23.
//

import UIKit

class DetailsViewController: UIViewController {
    
    
    @IBOutlet weak var discriptionLbl: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    
    var dis = ""
    var imgName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        discriptionLbl.text = dis
        imgView.image = UIImage(named: imgName)
        imgView.frame = CGRect(x: Int(view.center.x), y: Int(view.center.y), width: 200, height: 150)
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1.0, delay: 0.2, usingSpringWithDamping: 0.5, initialSpringVelocity: 0.6) {
            self.imgView.frame = CGRect(x: Int(self.view.center.x), y: Int(self.view.center.y), width: 240, height: 180)
        }
        imgView.frame = CGRect(x: 100, y: Int(view.center.y), width: 200, height: 150)
    }
    


}
