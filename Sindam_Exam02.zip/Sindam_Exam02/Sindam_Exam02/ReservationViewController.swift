//
//  ReservationViewController.swift
//  Sindam_Exam02
//
//  Created by Sindam,Suresh on 4/11/23.
//

import UIKit

class ReservationViewController: UIViewController {

    
    @IBOutlet weak var disLbl: UILabel!
    
    @IBOutlet weak var imgView: UIImageView!
    
    
    var dis = ""
    var imgName = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        disLbl.text = dis
        imgView.image = UIImage(named: imgName)
        imgView.frame.origin.x = view.frame.width
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 1.0) {
            self.imgView.center.x = self.view.center.x
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
