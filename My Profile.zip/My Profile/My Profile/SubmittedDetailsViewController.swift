//
//  SubmittedDetailsViewController.swift
//  My Profile
//
//  Created by Sindam,Suresh on 4/3/23.
//

import UIKit

class SubmittedDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var userNameLbl: UILabel!
    @IBOutlet weak var userAgeLbl: UILabel!
    @IBOutlet weak var userMobileNoLbl: UILabel!
    @IBOutlet weak var userEMailLbl: UILabel!
    
    var userName = ""
    var userAge = ""
    var userPhNo = ""
    var userEmail = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userNameLbl.text = userName
        userAgeLbl.text = userAge
        userMobileNoLbl.text = userPhNo
        userEMailLbl.text = userEmail
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
