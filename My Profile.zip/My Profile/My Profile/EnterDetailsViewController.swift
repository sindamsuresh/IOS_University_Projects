//
//  ViewController.swift
//  My Profile
//
//  Created by Sindam,Suresh on 4/3/23.
//

import UIKit

class EnterDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var nameTxtField: UITextField!
    @IBOutlet weak var dobTxtField: UITextField!
    @IBOutlet weak var mobileNoTxtField: UITextField!
    @IBOutlet weak var emailTxtField: UITextField!
    
    var calculatedAge = "0"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    
    @IBAction func findAgeAndShowDetailsBtnAction(_ sender: UIButton) {
        // calculating age based on birth year
        let currentYear = Calendar.current.component(.year, from: Date())
        let calculateAge = currentYear - Int(dobTxtField.text!)!
        calculatedAge = "\(calculateAge)"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "detailsSegue") {
            let dvc = segue.destination as! SubmittedDetailsViewController
            dvc.userName = nameTxtField.text!
            dvc.userAge = calculatedAge
            dvc.userPhNo = mobileNoTxtField.text!
            dvc.userEmail = emailTxtField.text!
            
            nameTxtField.text = ""
            dobTxtField.text = ""
            mobileNoTxtField.text = ""
            emailTxtField.text = ""
            
        }
    }
    
    


}

