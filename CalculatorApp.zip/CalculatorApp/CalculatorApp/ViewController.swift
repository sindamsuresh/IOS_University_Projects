//
//  ViewController.swift
//  CalculatorApp
//
//  Created by Sindam,Suresh on 2/2/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var resultLbl: UILabel!
    
    var operand1 = -1.1
    var _operator = " "
    var operand2 = -1.1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btn5Action(_ sender: UIButton) {
        resultLbl.text = resultLbl.text! + "5"
        if(operand1 == -1.1) {
            operand1 = 5
        } else {
            operand2 = 5
        }
    }
    
    @IBAction func btnPlusAction(_ sender: UIButton) {
        resultLbl.text = resultLbl.text! + "+"
        if(_operator == " ") {
            _operator = "+"
        }
    }
    
    @IBAction func btn3Action(_ sender: UIButton) {
        resultLbl.text = resultLbl.text! + "3"
        if(operand2 == -1.1) {
            operand2 = 3
        } else {
            operand1 = 3
        }
    }
    
    @IBAction func btnEqualsAction(_ sender: UIButton) {
        resultLbl.text = "="
        
        resultLbl.text = "\(operand1+operand2)"
    }
    


}

