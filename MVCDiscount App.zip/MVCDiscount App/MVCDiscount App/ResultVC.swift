//
//  ResultVC.swift
//  MVCDiscount App
//
//  Created by Sindam,Suresh on 3/30/23.
//

import UIKit

class ResultVC: UIViewController {
    
    
    @IBOutlet weak var enterAmountLbl: UILabel!
    @IBOutlet weak var enterDisRateLbl: UILabel!
    @IBOutlet weak var priceAfterDisLbl: UILabel!
    
    var enterAmount: String = ""
    var enterDis: String = ""
    var priceAfterDis: String = ""

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        enterAmountLbl.text! += enterAmount + "$"
        enterDisRateLbl.text! += enterDis + "%"
        priceAfterDisLbl.text! += priceAfterDis
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
