//
//  ViewController.swift
//  MVCDiscount App
//
//  Created by Sindam,Suresh on 3/30/23.
//

import UIKit

class HomeViewController: UIViewController {
    
    
    
    @IBOutlet weak var enterAmountTextField: UITextField!
    
    
    @IBOutlet weak var discountTextField: UITextField!
    
    var afterDisAmount = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    @IBAction func calculatePriceAfterDiscountBtnAction(_ sender: UIButton) {
        
        let amount = Double(enterAmountTextField.text!)
        
        let dis = Double(discountTextField.text!)
        
        let cal = amount! * dis!
        
        
        
        afterDisAmount = amount! - (cal / 100)
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "resultSegue") {
            let dvc = segue.destination as! ResultVC
            dvc.enterAmount = enterAmountTextField.text!
            dvc.enterDis = discountTextField.text!
            dvc.priceAfterDis = String(afterDisAmount)
        }
    }
    
    
}

