//
//  ViewController.swift
//  VowelsApp
//
//  Created by Sindam,Suresh on 1/31/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var wordTextField: UITextField!
    
    @IBOutlet weak var displayResultLbl: UILabel!
    
    var vowels = ["a", "e", "i", "o", "u", "A", "E", "I", "O", "U"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func checkVowelsBtn(_ sender: Any) {
        
        var vowelCount = 0
        
        for ch in wordTextField.text! {
          if (vowels.contains("\(ch)")) {
            vowelCount += 1
          }
        }
        // check vowels count
        if(vowelCount > 0) {
            displayResultLbl.text = "The Entered Text has vowels 😀"
        } else {
            displayResultLbl.text = "The Entered Text has no vowels 🥲"
        }
    }
    
}

