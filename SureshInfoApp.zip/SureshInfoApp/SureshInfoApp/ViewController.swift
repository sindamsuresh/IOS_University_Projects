//
//  ViewController.swift
//  SureshInfoApp
//
//  Created by Sindam,Suresh on 1/26/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var sidField: UITextField!
    @IBOutlet weak var n1nField: UITextField!
    @IBOutlet weak var phField: UITextField!
    
    @IBOutlet weak var displayLbl: UILabel!
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func submitBtnAction(_ sender: Any) {
        
        displayLbl.text = "Name : \(nameField.text!)\n Sid : \(sidField.text!)\n 919 : \(n1nField.text!)\n Ph no : \(phField.text!)"
    }
    
}

