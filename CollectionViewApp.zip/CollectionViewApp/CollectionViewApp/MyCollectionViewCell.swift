//
//  MyCollectionViewCell.swift
//  CollectionViewApp
//
//  Created by Sindam,Suresh on 4/27/23.
//

import UIKit

class MyCollectionViewCell: UICollectionViewCell {
    
}
