//
//  ViewController.swift
//  CollectionViewApp
//
//  Created by Sindam,Suresh on 4/27/23.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

