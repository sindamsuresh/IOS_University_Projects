//
//  ViewController.swift
//  DiscountApp
//
//  Created by Sindam,Suresh on 2/14/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var amountTxtField: UITextField!
    @IBOutlet weak var discountTxtField: UITextField!
    
    
    @IBOutlet weak var displayPriceLbl: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    
    @IBAction func calculateDisBtnAction(_ sender: UIButton) {
        
        var discountedPrice: Double = (Double(amountTxtField.text!)! * Double(discountTxtField.text!)!) / 100.0
        print(discountedPrice)
        
        
        
        displayPriceLbl.text = "price after discount \(Double(amountTxtField.text!)! - discountedPrice)"
        
    }
    
    

}

