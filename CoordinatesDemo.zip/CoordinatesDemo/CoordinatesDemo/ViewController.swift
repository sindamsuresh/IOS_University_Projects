//
//  ViewController.swift
//  CoordinatesDemo
//
//  Created by Sindam,Suresh on 3/23/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imgView: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        let minX = imgView.frame.minX
        let minY = imgView.frame.minY
        print("\(minX), \(minY)")
        
        let maxX = imgView.frame.maxX
        let maxY = imgView.frame.maxY
        print("\(maxX), \(maxY)")
        
        let midX = imgView.frame.midX
        let midY = imgView.frame.midY
        print("\(midX), \(midY)")
        
        // left upper corner
        imgView.frame.origin.x = 0
        imgView.frame.origin.y = 0
        
        // right upper corner
        imgView.frame.origin.x = 414 - 100
        imgView.frame.origin.y = 0
        
        // left below corner
        imgView.frame.origin.x = 0
        imgView.frame.origin.y = 896-100
        
        // right upper corner
        imgView.frame.origin.x = 414 - 100
        imgView.frame.origin.y = 896-100
        
        // mid point
//        imgView.frame.origin.x = UIScreen().bounds.midX
//        imgView.frame.origin.y = UIScreen().bounds.midY
        
        imgView.frame.origin.x = self.view.frame.size.width/2 - 50
        imgView.frame.origin.y = self.view.frame.size.height/2 - 50
        
        print(imgView.frame.origin.x)
        print(imgView.frame.origin.y)
        
        
    }


}

