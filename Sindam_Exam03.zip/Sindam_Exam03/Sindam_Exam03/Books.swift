//
//  Books.swift
//  Sindam_Exam03
//
//  Created by Sindam,Suresh on 4/27/23.
//

import Foundation

struct Books {
    var bookName: String?
    var bookImage: String?
}


let book1 = Books(bookName: "Swift", bookImage: "swift");
let book2 = Books(bookName: "Java", bookImage: "java");
let book3 = Books(bookName: "Python", bookImage: "python");
let book4 = Books(bookName: "JavaScript", bookImage: "javascript");
let book5 = Books(bookName: "C", bookImage: "c");
let book6 = Books(bookName: "C++", bookImage: "c++");

var booksArr = [book1,book2,book3,book4,book5,book6]
