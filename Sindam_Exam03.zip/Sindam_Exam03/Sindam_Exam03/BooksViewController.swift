//
//  ViewController.swift
//  Sindam_Exam03
//
//  Created by Sindam,Suresh on 4/27/23.
//

import UIKit

class BooksViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var booksTableView: UITableView!
    
    var programmingBooksArr = booksArr
    
    override func viewDidLoad() {
        super.viewDidLoad()
        booksTableView.delegate = self
        booksTableView.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        programmingBooksArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "bookCell", for: indexPath)
        cell.textLabel?.text = programmingBooksArr[indexPath.row].bookName
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "bookSegue" {
            let dvc = segue.destination as! BooksImageViewController
            dvc.programmingBookObj = programmingBooksArr[booksTableView.indexPathForSelectedRow!.row]
        }
    }


}

