//
//  BooksImageViewController.swift
//  Sindam_Exam03
//
//  Created by Sindam,Suresh on 4/27/23.
//

import UIKit

class BooksImageViewController: UIViewController {
    
    @IBOutlet weak var bookTitleLbl: UILabel!
    
    @IBOutlet weak var bookImgView: UIImageView!
    
    
    var programmingBookObj: Books?

    override func viewDidLoad() {
        super.viewDidLoad()
        bookTitleLbl.text = programmingBookObj?.bookName!
        bookImgView.image = UIImage(named: (programmingBookObj?.bookImage!)!)
    }
    
    
    @IBAction func animateBtnAction(_ sender: UIButton) {
        bookImgView.alpha = 0
        UIView.animate(withDuration: 10.0, delay: 0.1, usingSpringWithDamping: 0.1, initialSpringVelocity: 0.1) {
            self.bookImgView.alpha = 1
        }
    }
    


}
