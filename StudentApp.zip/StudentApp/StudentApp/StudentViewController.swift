//
//  ViewController.swift
//  StudentApp
//
//  Created by Sindam,Suresh on 4/4/23.
//

import UIKit

class StudentViewController: UIViewController {
    
    
    @IBOutlet weak var stuIdTextField: UITextField!
    
    
    var studentArr = students
    var isStudent = false
    var studentFund = Student()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    
    @IBAction func getStudentDetails(_ sender: UIButton) {
        
        let sid = stuIdTextField.text!
        
        for student in studentArr {
            if(student.sid == sid) {
                studentFund = student
                isStudent = true
            }
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "studentInfoSegue") {
            let dvc = segue.destination as! DeatilsViewController
            if isStudent {
                dvc.studentObj = studentFund
            }else{
                //if the given sid is not in the array, then the student is a guest!!
                //we set the boolean in the destination as true!!
                dvc.guestUser = true
            }
            
        }
    }
    
    
}

