//
//  DeatilsViewController.swift
//  StudentApp
//
//  Created by Sindam,Suresh on 4/4/23.
//

import UIKit

class DeatilsViewController: UIViewController {
    
    
    @IBOutlet weak var sidLbl: UILabel!
    
    @IBOutlet weak var nameLbl: UILabel!
    
    @IBOutlet weak var emailLbl: UILabel!
    
    @IBOutlet weak var viewCourseBtn: UIButton!
    
    
    var studentObj = Student()
    
    var guestUser = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if(guestUser) {
            sidLbl.isHidden = true
            nameLbl.text = "Name: Guest User"
            emailLbl.isHidden = true
            viewCourseBtn.isHidden = true
        } else {
            sidLbl.text = "SID: " + studentObj.sid
            nameLbl.text = "Name: " + studentObj.sName
            emailLbl.text = "Email: " + studentObj.email
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "courseInfoSegue") {
            let dvc = segue.destination as! CourseDetailsViewController
            dvc.courseArr = studentObj.coursesArr
        }
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
