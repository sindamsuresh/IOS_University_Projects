//
//  CourseDetailsViewController.swift
//  StudentApp
//
//  Created by Sindam,Suresh on 4/4/23.
//

import UIKit

class CourseDetailsViewController: UIViewController {
    
    
    @IBOutlet weak var courseLbl: UILabel!
    
    @IBOutlet weak var imgCourse: UIImageView!
    
    @IBOutlet weak var imgCourse1: UIImageView!

    @IBOutlet weak var imgCourse2: UIImageView!

    
    var courseArr: [Course] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        imgCourse.image = UIImage(named: courseArr[0].cImg)
        imgCourse.image = UIImage(named: courseArr[1].cImg)
        imgCourse.image = UIImage(named: courseArr[2].cImg)
        
        for course in courseArr {
            courseLbl.text = courseLbl.text! + course.cTitle + "-" + course.cSem + "\n"
        }
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
