//
//  Student.swift
//  StudentApp
//
//  Created by Sindam,Suresh on 4/4/23.
//

import Foundation

struct Student {
    var sName = ""
    var sid = ""
    var email = ""
    var coursesArr: [Course] = []
}

struct Course {
    var cTitle = ""
    var cSem = ""
    var cImg = ""
}



let student1 = Student(sName: "Suresh", sid: "S555653", email: "s@gmail.com",
                       coursesArr: [Course(cTitle: "IOS", cSem: "SP23", cImg: "ios"),
                                    Course(cTitle:"Data Structures",cSem:"sp22", cImg: "Data"),
                                    Course(cTitle:"java",cSem:"sp22", cImg: "java")])

let student2 = Student(sName: "Ramesh", sid: "S555654", email: "R@gmail.com",
                       coursesArr: [Course(cTitle: "Android", cSem: "SP23", cImg: "android"),
                                    Course(cTitle:"Data Structures",cSem:"sp22", cImg: "Data"),
                                    Course(cTitle:"java",cSem:"sp22", cImg: "java")])



let student3 = Student(sName: "Ram", sid: "S555655", email: "ram@gmail.com",
                       coursesArr: [Course(cTitle: "IOS", cSem: "SP23", cImg: "ios"),
                                    Course(cTitle:"Android",cSem:"sp22", cImg: "android"),
                                    Course(cTitle:"java",cSem:"sp22", cImg: "java")])


let students: [Student] = [student1,student2,student3]
