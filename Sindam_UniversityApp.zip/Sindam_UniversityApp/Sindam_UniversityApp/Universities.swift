//
//  Universities.swift
//  Sindam_UniversityApp
//
//  Created by Sindam,Suresh on 4/18/23.
//

import Foundation

struct Universities {
    var domain = ""
    var list_Array : [UniversityList] = []
}


struct UniversityList {
    var collegeName = ""
    var collegeImage = ""
    var collegeInfo = ""
}

var university1 = UniversityList(collegeName: "Harvard University", collegeImage: "Harvard", collegeInfo: "Harvard University is a private Ivy League research university in Cambridge, Massachusetts. Founded in 1636 as Harvard College and named for its first benefactor, the Puritan clergyman John Harvard, it is the oldest institution of higher learning in the United States. Its influence, wealth and rankings have made it one of the most prestigious universities in the world.")

var university2 = UniversityList(collegeName: "Stanford University",collegeImage: "Stanford", collegeInfo: "The Leland Stanford Junior University, better known as simply Stanford University, is one of the top universities in the US. It boasts respected programs across seven schools and about 20 interdisciplinary institutes, such as business, engineering, law, and medicine, among others. Stanford serves about 17,000 students (taught by nearly 2,280 faculty members)")

var university3 = UniversityList(collegeName: "Princeton University",collegeImage: "Princeton", collegeInfo: "Princeton University is an educational and research institution that provides academic programs in arts and sciences. The university offers undergraduate, graduate, doctorate, and professional education. It focuses on areas such as anthropology, architecture, chemistry, computer science, biology, neuroscience, economics, geosciences, operations research, and civil and environmental engineering.")

var university4 = UniversityList(collegeName: "The University of Chicago",collegeImage: "Chicago", collegeInfo: "The University of Chicago ranks among the world's most esteemed major universities. The private institution has an enrollment of some 7,010 undergraduate and about 10,460 graduate students. The undergraduate branch offers a core liberal arts curriculum and majors in about 55 majors and over 45 minor areas")

var university5 = UniversityList(collegeName: "Northwest Missouri State University",collegeImage: "Northwest", collegeInfo: "Northwest Missouri State University (NW Missouri) is a public university in Maryville, Missouri. It has an enrollment of about 8,505 students. Founded in 1905 as a teachers college, its campus is based on the design for Forest Park at the 1904 St. Louis World's Fair and is the official Missouri State Arboretum.The school is governed by a state-appointed Board of Regents and headed by Interim President Clarence Green.")

var university6 = UniversityList(collegeName: "California Institute of Technology",collegeImage: "California", collegeInfo: "The California Institute of Technology is a private research university in Pasadena, California. The university is responsible for many modern scientific advancements and is among a small group of institutes of technology in the United States which is strongly devoted to the instruction of pure and applied sciences.")


var university7 = UniversityList(collegeName: "University of Pennsylvania",collegeImage: "Pennsylvania", collegeInfo: "The University of Pennsylvania, often abbreviated simply as Penn or UPenn,is a private Ivy League research university in Philadelphia. It was one of nine colonial colleges chartered prior to the U.S. Declaration of Independence when Benjamin Franklin, the university's founder and first president, advocated for an educational institution that trained leaders in academia, commerce, and public service.Penn identifies as the fourth-oldest institution of higher education in the United States, though this representation is challenged by other universities. Benjamin Franklin and other Philadelphians established the university in 1749, which would make it the fifth-oldest institution of higher education.")


var domain1 = Universities(domain: "Computer Science",
                        list_Array: [university1,
                                     university2,
                                     university3,
                                     university4,
                                     university5,
                                     university6,
                                     university7])

var domain2 = Universities(domain: "Information Technology",
                        list_Array: [university2,
                                     university4,
                                     university1,
                                     university3,
                                     university5])


var domain3 = Universities(domain: "Data Science",
                           list_Array: [university1,
                                        university2,
                                        university3,
                                        university6,
                                        university7])

var domain4 = Universities(domain: "Busniess Management",
                           list_Array: [university7,
                                        university1,
                                        university4,
                                        university6,
                                        university2])

var domainsArr = [domain1, domain2, domain3, domain4]
