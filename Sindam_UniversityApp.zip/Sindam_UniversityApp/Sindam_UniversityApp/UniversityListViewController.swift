//
//  UniversityListViewController.swift
//  Sindam_UniversityApp
//
//  Created by Sindam,Suresh on 4/18/23.
//

import UIKit

class UniversityListViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var universityListTableView: UITableView!
    
    
    var universitiesList: [UniversityList] = []
    var selectedDomain = ""

    override func viewDidLoad() {
        super.viewDidLoad()
        universityListTableView.dataSource = self
        //universityListTableView.delegate = self
        self.title = selectedDomain
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        universitiesList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        cell.textLabel?.text = universitiesList[indexPath.row].collegeName
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "universityInfoSegue") {
            let dvc = segue.destination as! UniversityInfoViewController
            dvc.selectedUnivesityData = universitiesList[universityListTableView.indexPathForSelectedRow!.row]
        }
    }

}
