//
//  UniversityInfoViewController.swift
//  Sindam_UniversityApp
//
//  Created by Sindam,Suresh on 4/18/23.
//

import UIKit

class UniversityInfoViewController: UIViewController {
    
    
    @IBOutlet weak var universityImageViewOutlet: UIImageView!
    
    @IBOutlet weak var universityInfoOutlet: UITextView!
    
    var selectedUnivesityData: UniversityList?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = selectedUnivesityData?.collegeName
        universityImageViewOutlet.image = UIImage(named: selectedUnivesityData!.collegeImage)
        universityImageViewOutlet.frame.origin.x = view.frame.width
        universityInfoOutlet.isHidden = true
    }
    
    override func viewDidAppear(_ animated: Bool) {
        UIView.animate(withDuration: 2.0) {
            self.universityImageViewOutlet.center.x = self.view.frame.width/2
        }
    }
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        universityInfoOutlet.text = selectedUnivesityData!.collegeInfo
        universityInfoOutlet.isHidden = false
    }
    
    

}
