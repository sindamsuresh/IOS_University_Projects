//
//  ViewController.swift
//  Sindam_UniversityApp
//
//  Created by Sindam,Suresh on 4/18/23.
//

import UIKit

class UniversitiesViewController: UIViewController, UITableViewDataSource {
    
    @IBOutlet weak var universitiesTableView: UITableView!
    
    var listOfDOmains = domainsArr
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        universitiesTableView.dataSource = self
        //universitiesTableView.delegate = self
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        listOfDOmains.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "domainCell", for: indexPath)
        cell.textLabel?.text = listOfDOmains[indexPath.row].domain
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if(segue.identifier == "listsSegue") {
            let dvc = segue.destination as! UniversityListViewController
            dvc.selectedDomain = listOfDOmains[universitiesTableView.indexPathForSelectedRow!.row].domain
            dvc.universitiesList = listOfDOmains[universitiesTableView.indexPathForSelectedRow!.row].list_Array
        }
    }
    
    
    


}

