//
//  ViewController.swift
//  Sindam_Exam01
//
//  Created by Sindam,Suresh on 2/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var inrTextField: UITextField!
    
    
    @IBOutlet weak var imgView: UIImageView!
    
    @IBOutlet weak var resultLbl: UILabel!
    
    var oneUSDInINR = 82.93
    var oneUSDInCAD = 1.26
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        imgView.image = UIImage(named: "default")
    }
    
    
    @IBAction func convertToUSD(_ sender: UIButton) {
        if(inrTextField.text!.isEmpty) {
            resultLbl.text = "Please enter some amount"
            imgView.image = UIImage(named: "oops")
        } else if(Double(inrTextField.text!)! == 0.0)  {
            resultLbl.text = "₹ \(Double(inrTextField.text!)!) oops! cannot convert"
            imgView.image = UIImage(named: "oops")
        } else {
            let convertCurrency = Double(inrTextField.text!)! / oneUSDInINR
            let roundedCurrencyValue = round(convertCurrency*100)/100.0
            imgView.image = UIImage(named: "usd")
            resultLbl.text = "₹ \(Double(inrTextField.text!)!) in USD is: $\(roundedCurrencyValue)"
        }
    }
    
    @IBAction func convertToCAD(_ sender: UIButton) {
        if(inrTextField.text!.isEmpty) {
            resultLbl.text = "Please enter some amount"
            imgView.image = UIImage(named: "oops")
        } else if(Double(inrTextField.text!)! == 0.0) {
            resultLbl.text = "₹ \(Double(inrTextField.text!)!) oops! cannot convert"
            imgView.image = UIImage(named: "oops")
        } else {
            let convertCurrency = (Double(inrTextField.text!)!*oneUSDInCAD)  / oneUSDInINR
            let roundedCurrencyValue = round(convertCurrency*100)/100.0
            imgView.image = UIImage(named: "cad")
            resultLbl.text = "₹ \(Double(inrTextField.text!)!) in CAD is: $\(roundedCurrencyValue)"
        }
    }
    
    

}

