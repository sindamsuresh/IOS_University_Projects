//
//  ViewController.swift
//  testExam
//
//  Created by Sindam,Suresh on 2/28/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var patientName: UITextField!
    
    @IBOutlet weak var surgeryType: UITextField!
    
    @IBOutlet weak var cost: UITextField!
    
    
    @IBOutlet weak var img: UIImageView!
    
    
    @IBOutlet weak var result: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func calculate(_ sender: Any) {
        
        var patName = patientName.text!
        var surType = surgeryType.text!
        //var surCost = Double(cost.text!)!
        
        
        if(patName.isEmpty && surType.isEmpty && cost.text!.isEmpty) {
            result.text = "please enter value"
            img.image = UIImage(named: "noResults")
        } else {
            
            //Total Surgery Cost=Surgery Cost(1+Tax%)-Health Insurance
            var totalCost = 0.0
            
            if(surgeryType.text?.lowercased() == "heart") {
                
                totalCost = Double(cost.text!)!*(1 + (11.75/100)) - 500
                var roundedCOst  = round(totalCost * 100.0)/100.0
                img.image = UIImage(named: "Heart")
                result.text = "Patient Name: \(patName)" + "\n" + "Surgery Type: \(surType)" + "\n" + "total cost: \(roundedCOst)"
                
                
            } else if(surgeryType.text?.lowercased() == "brain") {
                totalCost = Double(cost.text!)!*(1 + (13.5/100)) - 750
                var roundedCOst  = round(totalCost * 100.0)/100.0
                img.image = UIImage(named: "Brain")
                result.text = "Patient Name: \(patName)" + "\n" + "Surgery Type: \(surType)" + "\n" + "total cost: \(roundedCOst)"
            } else if(surgeryType.text?.lowercased() == "knee") {
                totalCost = Double(cost.text!)!*(1 + (6.25/100)) - 350
                var roundedCOst  = round(totalCost * 100.0)/100.0
                img.image = UIImage(named: "Knee")
                result.text = "Patient Name: \(patName)" + "\n" + "Surgery Type: \(surType)" + "\n" + "total cost: \(roundedCOst)"
            }
            
        }
        
    }
    

}

