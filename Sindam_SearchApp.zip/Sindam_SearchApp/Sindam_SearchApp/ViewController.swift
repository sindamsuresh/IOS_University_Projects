//
//  ViewController.swift
//  Sindam_SearchApp
//
//  Created by Sindam,Suresh on 3/21/23.
//

import UIKit

class ViewController: UIViewController {
    
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    @IBOutlet weak var topicInfoText: UITextView!
    
    @IBOutlet weak var searchBtn: UIButton!
    
    @IBOutlet weak var btnsStackVIew: UIStackView!
    
    @IBOutlet weak var prevBtn: UIButton!
    @IBOutlet weak var nextBtn: UIButton!
    
    var topicImgArr = [["tesla","bmw","toyota","benz","ferrari"],
                       ["harley-davidson","yamaha","kawasaki","bmw motorrad","benelli"],
                       ["pawan kalyan","allu arjun","vijay devarakonda","jr ntr","ram charan"]]
    
    
    var cars_keywords = ["cars","4 wheeler","automobiles","steering","sports car"]
    var bikes_keywords = ["bikes","2 wheeler","helmet","scooty","Sports bike"]
    var actors_keywords = ["actor","hero","movie","flim","character"]
    
    var topic = 0
    var imageIndex = 0
    
    
    //    var teslaCarDiscription = "All Tesla models are equipped with a driver assistance system called Autopilot. The feature enables a car to steer, accelerate, and brake automatically within its lane. The function does not replace the role of a driver, but is intended to make driving easier and cut down on accidents.";
    //
    
    
    var topics_array = [["All Tesla models are equipped with a driver assistance system called Autopilot. The feature enables a car to steer, accelerate, and brake automatically within its lane. The function does not replace the role of a driver, but is intended to make driving easier and cut down on accidents.", "This is a compact four-door coupe that offers a sporty driving experience with its turbocharged engines and agile handling. It comes with a variety of features including a digital instrument cluster, iDrive infotainment system, and driver assistance technologies.","This is a mid-size crossover SUV that was redesigned for 2021. It features a hybrid powertrain that delivers impressive fuel economy, a spacious and comfortable interior, and advanced safety features such as automatic emergency braking and lane departure warning.","This is a fully electric luxury sedan with a range of up to 478 miles. It features a futuristic and aerodynamic design, a 56-inch hyperscreen that spans the entire dashboard, and advanced driver assistance features such as automated parking.","This is a grand touring sports car that combines timeless design with modern technology. It features a 3.9-liter V8 engine that produces 612 horsepower, and can accelerate from 0 to 60 mph in just 3.3 seconds. The Roma also features a spacious and luxurious interior with advanced technology features."],
                        ["This is a new streetfighter motorcycle with a liquid-cooled 975cc Revolution Max engine that produces 115 horsepower. It features a lightweight chassis and a sporty design, with a range of advanced technology features such as ABS, traction control, and multiple riding modes.","This is a new entry-level sportbike that replaces the YZF-R6. It features a 689cc liquid-cooled parallel-twin engine that produces 73 horsepower, and a lightweight chassis. The R7 also features advanced technology such as adjustable KYB suspension, ABS, and multiple riding modes.","These are high-performance sportbikes with a liquid-cooled 998cc inline-four engine that produces 203 horsepower. The ZX-10R features a range of advanced technology such as electronic throttle valves, quick shifter, and launch control. The ZX-10RR is a limited edition model with even more track-focused features.","The BMW R 18 Transcontinental is a touring motorcycle with a classic design, inspired by BMW's historical models. It has a massive 1,802cc air/oil-cooled boxer engine that produces 91 horsepower and 116 lb-ft of torque. The engine is mated to a 6-speed transmission with a hydraulic clutch.","The Benelli TRK502X is an adventure touring motorcycle that is designed to tackle both on-road and off-road riding conditions. It has a liquid-cooled 500cc parallel-twin engine that produces 47 horsepower and 33 lb-ft of torque. The engine is mated to a 6-speed transmission with a slipper clutch."],
                        ["Kalyan was born on 2 September in 1968 or 1971 to Konidela Venkata Rao and Anjana Devi in Bapatla, Andhra Pradesh. He is the younger brother of Chiranjeevi and Nagendra Babu. He was awarded Pawan during one of his public martial arts presentations. He holds a black belt in karate.","Allu Arjun (born 8 April 1982) is an Indian actor who works in Telugu films. One of the highest paid actors in India, Arjun is also known for his extraordinary dancing skills. He is a recipient of several awards including six Filmfare Awards and three Nandi Awards. Allu Arjun made his debut with Gangotri in 2003.","Deverakonda Vijay Sai (born 9 May 1989), better known as Vijay Deverakonda, is an Indian actor and film producer who works predominantly in Telugu cinema. He is the recipient of a Filmfare Award, a Nandi Award, and a SIIMA Award. Since 2018, he has featured in Forbes India's Celebrity 100 list.","Rama Rao was born on 20 May 1983 as son to film actor and politician, Nandamuri Harikrishna and Shalini Bhaskar Rao. His father is of Telugu descent and his mother is a Kannadiga, who hails from Kundapur, Karnataka. He is the grandson of Telugu actor and former Chief Minister of Andhra Pradesh, N. T. Rama Rao.","Konidela Ram Charan Teja (born 27 March 1985) is an Indian actor, producer, and entrepreneur who primarily works in Telugu films. One of the highest-paid actors in Indian cinema,[3][4] he is the recipient of three Filmfare Awards and two Nandi Awards. Since 2013, he has featured in Forbes India's Celebrity 100 list."]]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        utilUIElements()
    }
    
    
    @IBAction func searchButtonAction(_ sender: UIButton) {
        imageIndex = 0
        topicInfoText.text = ""
        topicInfoText.isUserInteractionEnabled = true
        if(cars_keywords.contains(searchTextField.text!)) {
            topic = 1
            prevBtn.isEnabled = false
            nextBtn.isEnabled = true
            btnsStackVIew.isHidden = false
            resultImage.image = UIImage(named: topicImgArr[0][0])
            topicInfoText.text = topics_array[0][0]
            
        } else if(bikes_keywords.contains(searchTextField.text!)) {
            topic = 2
            prevBtn.isEnabled = false
            nextBtn.isEnabled = true
            btnsStackVIew.isHidden = false
            resultImage.image = UIImage(named: topicImgArr[1][0])
            topicInfoText.text = topics_array[1][0]
            
        } else if(actors_keywords.contains(searchTextField.text!)) {
            topic = 3
            prevBtn.isEnabled = false
            nextBtn.isEnabled = true
            btnsStackVIew.isHidden = false
            resultImage.image = UIImage(named: topicImgArr[2][0])
            topicInfoText.text = topics_array[2][0]
        } else {
            resultImage.image = UIImage(named: "search not found")
            btnsStackVIew.isHidden = true
            topicInfoText.isUserInteractionEnabled = false
        }
    }
    
    @IBAction func ShowNextImagesBtn(_ sender: UIButton) {
        imageIndex += 1
        nextBtn.isEnabled = true
        prevBtn.isEnabled = true
        switch topic {
        case 1:
            resultImage.image = UIImage(named: topicImgArr[0][imageIndex])
            topicInfoText.text = topics_array[0][imageIndex]
        case 2:
            resultImage.image = UIImage(named: topicImgArr[1][imageIndex])
            topicInfoText.text = topics_array[1][imageIndex]
        case 3:
            resultImage.image = UIImage(named: topicImgArr[2][imageIndex])
            topicInfoText.text = topics_array[2][imageIndex]
        default:
            print("enter into default")
        }
        
        if(imageIndex == topicImgArr[0].count - 1) {
            nextBtn.isEnabled = false
        } else {
            nextBtn.isEnabled = true
        }
        
    }
    
    @IBAction func ShowPrevImagesBtn(_ sender: UIButton) {
        imageIndex -= 1
        nextBtn.isEnabled = true
        switch topic {
        case 1:
            resultImage.image = UIImage(named: topicImgArr[0][imageIndex])
            topicInfoText.text = topics_array[0][imageIndex]
        case 2:
            resultImage.image = UIImage(named: topicImgArr[1][imageIndex])
            topicInfoText.text = topics_array[1][imageIndex]
        case 3:
            resultImage.image = UIImage(named: topicImgArr[2][imageIndex])
            topicInfoText.text = topics_array[2][imageIndex]
        default:
            print("enter into default")
        }
        
        if(imageIndex == 0) {
            prevBtn.isEnabled = false
        } else {
            prevBtn.isEnabled = true
        }
    }
    
    @IBAction func ResetBtn(_ sender: UIButton) {
        searchTextField.text = ""
        imageIndex = 0
        utilUIElements()
    }
    
    
    @IBAction func editingTextField(_ sender: UITextField) {
        if searchTextField.text!.isEmpty {
            searchBtn.isEnabled = false
        } else {
            searchBtn.isEnabled = true
        }
    }
    
    func utilUIElements() {
        searchBtn.isEnabled = false
        resultImage.image = UIImage(named: "welcome")
        topicInfoText.text = ""
        topicInfoText.isUserInteractionEnabled = false
        btnsStackVIew.isHidden = true
        topic = 0
    }
    
    
}

