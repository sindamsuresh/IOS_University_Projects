//
//  ViewController.swift
//  Sindam_WordGuess
//
//  Created by Sindam,Suresh on 3/30/23.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    
    @IBOutlet weak var statusLabel: UILabel!
    
    
    @IBOutlet weak var displayImage: UIImageView!
    
    
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    
    @IBOutlet weak var playAgainBtn: UIButton!
    @IBOutlet weak var guessLetterBtn: UIButton!
    
    
    var wordsArr = [["IPHONE", "Gadget"],["MAC", "Operating System"], ["JAVA", "Programming Language"], ["NTR", "RRR Movie Hereos"], ["DOG", "Animal"]  ]
    
    var wordsImgArr = ["iphone", "mac", "java", "ntr", "dog"]
    
    var count = 0;
    var word = ""
    var lettersGuessed = ""
    var guessCount = 0
    
    let maxNumOfWrongGuesses = 10
    var successfulWordCount = 0
    var remainingWordCount = 5
    
    override func viewDidLoad() {
        super.viewDidLoad()
        guessLetterBtn.isEnabled = false
        playAgainBtn.isHidden = true
        statusLabel.text = ""
        
        wordsGuessedLabel.text! += "0"
        wordsRemainingLabel.text! += "5"
        totalWordsLabel.text! += String(wordsArr.count)
        
        word = wordsArr[count][0]
        hintLabel.text = "Hint: "+wordsArr[count][1]
        userGuessLabel.text = ""
        underscoreUpdate()
        
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: UIButton) {
        var letter = guessLetterField.text!
        guessCount += 1
        //Replace the guessed letter if the letter is part of the word.
        lettersGuessed += letter
        var revealedWord = ""
        for letter in word{
            if lettersGuessed.contains(letter){
                revealedWord += "\(letter)"
            }
            else{
                revealedWord += "_ "
            }
        }
        //Assigning the word to displaylabel after a guess
        userGuessLabel.text = revealedWord
        guessLetterField.text = ""
        guessCountLabel.text = "You have made \(guessCount) guesses"
        //If the word is guessed correctly, we are enabling play again button and disabling the check button.
        if userGuessLabel.text!.contains("_") == false{
            successfulWordCount += 1
            remainingWordCount -= 1
            playAgainBtn.isHidden = false;
            guessLetterBtn.isEnabled = false;
            displayImage.image = UIImage(named: wordsImgArr[count])
            guessCountLabel.text = "Wow! you have made \(guessCount) guesses to guess the word"
            wordsGuessedLabel.text! = "Total number of words guessed successfully: " + "\(successfulWordCount)"
            wordsRemainingLabel.text! = "Total number of words remaining in game: " + "\(remainingWordCount)"
        }
        
        if(guessCount > 10) {
            playAgainBtn.isHidden = false
            guessCountLabel.text = "You have used all the available guessess, Please Play Again"
            count -= 1
        }
        guessLetterBtn.isEnabled = false
        
//        if() {
//
//        }
        
    }
    
    
    @IBAction func playAgainButtonPressed(_ sender: UIButton) {
        //Reset the button to disable initially.
        playAgainBtn.isHidden = true
        displayImage.image = nil
        guessCount = 0
        guessCountLabel.text = "You have made \(guessCount) guesses"
        //clear the label
        lettersGuessed = ""
        count += 1
        //if count reaches the end of the array (all the words are guessed sucessfully), then print Congratualtions in the status label.
        if count == wordsArr.count{
            statusLabel.text = "Congruations! You are done with the game!"
            displayImage.image = UIImage(named: "alldone")
            //clearing the labels.
            userGuessLabel.text = ""
            hintLabel.text = ""
            guessCountLabel.text = ""
        }
        else{
            //fetch the next word from the array
            word = wordsArr[count][0]
            //fetch the hint related to the word
            hintLabel.text = "Hint: "
            hintLabel.text! += wordsArr[count][1]
            //Enabling the check button.
            guessLetterBtn.isEnabled = true
            
            userGuessLabel.text = ""
            underscoreUpdate()
        }
    }
    
    
    @IBAction func editingChangesTxtField(_ sender: UITextField) {
        if(guessLetterField.text!.isEmpty) {
            guessLetterBtn.isEnabled = false
        } else {
            guessLetterBtn.isEnabled = true
        }
    }
    func underscoreUpdate() {
        for i in 0..<word.count {
            userGuessLabel.text! += "_ "
        }
    }
}

