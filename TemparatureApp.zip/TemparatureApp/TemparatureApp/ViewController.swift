//
//  ViewController.swift
//  TemparatureApp
//
//  Created by Sindam,Suresh on 2/21/23.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var tempTxtField: UITextField!
    
    @IBOutlet weak var imgView: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func evaluateTemp(_ sender: UIButton) {
        var temp = Double(tempTxtField.text!)
        
        if(temp! < 0) {
            imgView.image = UIImage(named: "full snow")
        } else if(temp! < 20) {
            imgView.image = UIImage(named: "normal snow")
        } else {
            imgView.image = UIImage(named: "sunny image")
        }
    }
    
}

