//
//  movieCollectionViewCell.swift
//  Sindam_Movies
//
//  Created by Sindam,Suresh on 4/28/23.
//

import UIKit

class movieCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var movieImgView: UIImageView!
    
    
    func configureCell(img: UIImage) {
        movieImgView.image = img
    }
    
    
}
