//
//  ViewController.swift
//  Sindam_Movies
//
//  Created by Sindam,Suresh on 4/28/23.
//

import UIKit

class GenreViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    
    
    @IBOutlet weak var genreTableView: UITableView!
    
    
    var genreDataArr = genreArr
    

    override func viewDidLoad() {
        super.viewDidLoad()
        genreTableView.delegate = self
        genreTableView.dataSource = self
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        genreDataArr.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "sectionCell", for: indexPath)
        cell.textLabel?.text = genreDataArr[indexPath.row].category
        return cell
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "movieSeque" {
            let dvc = segue.destination as! MoviesViewController
            dvc.moviesList = genreDataArr[genreTableView.indexPathForSelectedRow!.row]
        }
    }
}

